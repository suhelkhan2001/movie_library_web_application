import 'package:movieapp/domain/entities/video_entity.dart';

class WatchVideoArguments {
  final List<VideoEntity> videos;

  WatchVideoArguments(this.videos);
}
