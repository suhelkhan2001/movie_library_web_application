class MovieDetailArguments {
  final int movieId;

  const MovieDetailArguments(this.movieId);
}
