class RouteList {
  RouteList._();

  static const String initial = '/';
  static const String home = '/home';
  static const String movieDetail = '/movie-detail';
  static const String watchTrailer = '/watch-trailer';
  static const String favorite = '/favorite';
}
