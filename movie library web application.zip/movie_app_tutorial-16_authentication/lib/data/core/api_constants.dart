class ApiConstants {
  ApiConstants._();

  static const String BASE_URL = "https://api.themoviedb.org/3/";
  static const String API_KEY = "f33521953035af3fc3162fe1ac22e60c";
  static const String BASE_IMAGE_URL = "https://image.tmdb.org/t/p/w500";
}
